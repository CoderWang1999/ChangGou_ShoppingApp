package com.changgou.goods.dao;
import com.changgou.goods.pojo.Spu;
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:admin
 * @Description:Spu的Dao
 * @Date 2019/6/14 0:12
 *****/
public interface SpuMapper extends Mapper<Spu> {
}
