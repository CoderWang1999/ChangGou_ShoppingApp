package com.changgou.item.service;

/**
 * 描述
 *
 * @author www.itheima.com
 * @version 1.0
 * @package com.changgou.item.service *
 * @since 1.0
 */
public interface PageService {
    //生成静态页
    void createPageHtml(Long id);
}
