package com.changgou.user.dao;
import com.changgou.user.pojo.UndoLog;
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:admin
 * @Description:UndoLog的Dao
 * @Date 2019/6/14 0:12
 *****/
public interface UndoLogMapper extends Mapper<UndoLog> {
}
