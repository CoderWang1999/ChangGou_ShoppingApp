package ${package_mapper};
import ${package_pojo}.${Table};
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:admin
 * @Description:${Table}的Dao
 * @Date 2019/6/14 0:12
 *****/
public interface ${Table}Mapper extends Mapper<${Table}> {
}
