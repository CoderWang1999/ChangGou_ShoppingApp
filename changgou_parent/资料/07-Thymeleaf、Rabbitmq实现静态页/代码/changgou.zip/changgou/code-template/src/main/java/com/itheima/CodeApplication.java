package com.itheima;

import com.itheima.code.build.TemplateBuilder;

/****
 * @Author:admin
 * @Description:
 * @Date 2019/6/14 23:43
 *****/
public class CodeApplication {

    public static void main(String[] args) {
        //调用该方法即可
        TemplateBuilder.builder();
    }
}
